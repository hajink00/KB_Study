package main.java.ch10_collection.practice.run;

import main.java.ch10_collection.practice.model.service.MainService;

public class UpDownCollectionRun {

}
